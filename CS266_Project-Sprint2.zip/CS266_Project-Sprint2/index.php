<?
 header( "location: login.php" );
 exit(0);
?>